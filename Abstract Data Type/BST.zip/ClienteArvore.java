public class ClienteArvore {

	public static void main(String[] args) {
        BST<String, Integer> st = new BST<String, Integer>();
        for (int i = 0; !StdIn.isEmpty(); i++) {
            String key = StdIn.readString();
            st.put(key, i);
        }
        
        System.out.println("Num de Nodes: "+ st.numNodes());
        System.out.println("Altura da Arvore: "+st.alturaTree());
        System.out.println("Menor valor: " + st.min());
        System.out.println("Maior valor: " + st.max());
                
        System.out.println("Pre-Ordem: "+st.preOrder());
    }
}
